"use strict"
const level4State={

preload:function() 

{
    preloadRecipes()
    preloadHouseB()
    game.load.image("bathroom", "images/BathStuff/bathroom2 fixed.jpg") 
    game.load.image("BHPB", "images/BHP/duck.png") 
    game.load.image("straw", "images/BathStuff/straw.png") 
    game.load.image("flour", "images/BathStuff/flour.png") 
},

create:function()

{
    beenRoom = true

    bathroom = game.add.image(500, 0, "bathroom")
    bathroom.anchor.setTo(0.5, 0)

    flour = game.add.image(465, 385, "flour")
    flour.scale.setTo(0.75)
    flour.inputEnabled = true
    flour.events.onInputDown.add(getFlour)

    straw = game.add.image(557, 160, "straw")
    straw.scale.setTo(0.75)
    straw.inputEnabled = true
    straw.events.onInputDown.add(getStraw)

    BHPB = game.add.image(527, 180, "BHPB")
    BHPB.scale.setTo(0.75)
    BHPB.inputEnabled = true
    BHPB.events.onInputDown.add(goToBHPB)

    createHouseB()    
    createRecipes()
}, 

update:function()

{ 
    if(gotFlour == true) {
        flour.alpha = 0
    }
    if(doneDuck == true) {
        if(gotStraw == false) {
            straw.alpha = 1
        }
        BHPB.inputEnabled = false
    }
    if(doneDuck == false) {
        straw.alpha = 0
    }
    if(gotStraw == true) {
        straw.alpha = 0
    }
}
}
function goToBHPB() {
    game.state.start('fifth',level5State)
}
function getFlour() {
    gotFlour = true
    flour.destroy()
}
function getStraw() {
    gotStraw = true
    straw.destroy()
}