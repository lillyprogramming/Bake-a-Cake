"use strict"
const level10State={

preload:function() 

{
    game.load.image("hid", "images/other/hid.png") 
    game.load.image("cake", "images/other/cake.png")
    game.load.image("youwin", 'images/other/youwin.png') 
},

create:function()

{
    hid = game.add.image(500, 0, "hid")
    hid.anchor.setTo(0.5, 0)
    
    cake = game.add.image(245, 435, "cake")
    cake.inputEnabled = true
    cake.events.onInputDown.add(getCake)

    youwin = game.add.image(0, 0, "youwin")
    youwin.alpha = 0
}, 

update:function()

{ 
    if(gotCake == true) {
        youwin.alpha = 1
    }
}
}
function getCake() {
    gotCake = true
    cake.destroy()
}