"use strict"
const level8State={

preload:function() 

{
    preloadRecipes()
    preloadHouseB()
    game.load.image("lg", "images/LivingStuff/lg.png") 
    game.load.image("LGPB", "images/LGP/LGPB.png") 
    game.load.image("vanilla", "images/LivingStuff/vanilla.png") 
    game.load.image("sugar", "images/LivingStuff/sugar.png") 
},
    
create:function()
    
{
    beenRoom = true
    
    lg = game.add.image(500, 0, "lg")
    lg.anchor.setTo(0.5, 0)
    
    vanilla = game.add.image(555, 415, "vanilla")
    vanilla.scale.setTo(0.75)
    vanilla.inputEnabled = true
    vanilla.events.onInputDown.add(getVanilla)
    
    sugar = game.add.image(265, 415, "sugar")
    sugar.scale.setTo(0.75)
    sugar.inputEnabled = true
    sugar.events.onInputDown.add(getSugar)
    
    LGPB = game.add.image(580, 175, "LGPB")
    LGPB.scale.setTo(0.75)
    LGPB.inputEnabled = true
    LGPB.events.onInputDown.add(goToLGPB)

    createHouseB()    
    createRecipes()
}, 
    
update:function()
    
{ 
    if(gotVanilla == true) {
            vanilla.alpha = 0
    }
    if(doneClock == true) {
        if(gotSugar == false) {
            sugar.alpha = 1
        }
        LGPB.inputEnabled = false
    }
    if(doneClock == false) {
        sugar.alpha = 0
    }
    if(gotSugar == true) {
        sugar.alpha = 0
    }
}
}
function goToLGPB() {
    game.state.start('seventh',level7State)
}
function getVanilla() {
    gotVanilla = true
    vanilla.destroy()
}
function getSugar() {
    gotSugar = true
    sugar.destroy()
}