"use strict"
const level11State={

preload:function() 

{    
    game.load.image("gameName", "images/level1Stuff/gamename2.png") 
    game.load.image("begin", "images/level1Stuff/begin.png")
    game.load.image("beginb", "images/level1Stuff/beginb.png")
    game.load.image("instructions", "images/level1Stuff/instructions2.png")
    game.load.image("understoodb", "images/level1Stuff/understoodb.png")
},

create:function()

{
    begin = game.add.image(0, 0, "begin")

    beginb = game.add.sprite(500, 600, "beginb")
    beginb.anchor.setTo(0.5)
    beginb.scale.setTo(0.35)
    beginb.inputEnabled = true
    beginb.events.onInputDown.add(beginGame)    

    gameName = game.add.sprite(500, 250, "gameName")
    gameName.anchor.setTo(0.5)    
    gameName.scale.setTo(1, 1.5)
},    


update:function()

{ 
    if(toInstructions == true) {
        instructions = game.add.image(0, 0, "instructions")

        understoodb = game.add.image(500, 600, "understoodb")
        understoodb.anchor.setTo(0.5)
        understoodb.scale.setTo(0.35)
        understoodb.inputEnabled = true
        understoodb.events.onInputDown.add(closeInstructions)
        toInstructions = false
    }
}
}

function beginGame() {
    toInstructions = true
    beginb.destroy()
    begin.destroy()
}
function closeInstructions() {
    game.state.start('first',level1State)
}