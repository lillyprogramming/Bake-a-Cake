"use strict"
const level5State={

preload:function() 

{
    game.load.image("db", "images/BHP/darkblue.png") 
    game.load.image("dg", "images/BHP/darkgreen.png") 
    game.load.image("dr", "images/BHP/darkred.png") 
    game.load.image("dy", "images/BHP/darkyellow.png") 
    game.load.image("lb", "images/BHP/lightblue.png") 
    game.load.image("lg", "images/BHP/lightgreen.png") 
    game.load.image("lr", "images/BHP/lightred.png") 
    game.load.image("ly", "images/BHP/lightyellow.png") 
    game.load.image("back", "images/BHP/backg.png") 
},

create:function()

{    
    back = game.add.image(0, 0, "back")
    back.scale.setTo(2)

    db = game.add.image(550, 410, "db")
    db.scale.setTo(2)
    db.inputEnabled = true
    db.events.onInputDown.add(blue)    
    
    lb = game.add.image(550, 410, "lb")
    lb.scale.setTo(2)
    lb.alpha = 0

    dg = game.add.image(150, 10, "dg")
    dg.scale.setTo(2)
    dg.inputEnabled = true
    dg.events.onInputDown.add(green)    
    
    lg = game.add.image(150, 10, "lg")
    lg.scale.setTo(2)
    lg.alpha = 0

    dr = game.add.image(550, 10, "dr")
    dr.inputEnabled = true
    dr.scale.setTo(2)
    dr.events.onInputDown.add(red)    
    
    lr = game.add.image(550, 10, "lr")
    lr.scale.setTo(2)
    lr.alpha = 0

    dy = game.add.image(150, 410, "dy")
    dy.inputEnabled = true
    dy.scale.setTo(2)
    dy.events.onInputDown.add(yellow)
    
    ly = game.add.image(150, 410, "ly")
    ly.scale.setTo(2)
    ly.alpha = 0    
}, 

update:function()

{ 
    if((pBlue == true)||(pRed == true)||(pGreen == true)||(pYellow == true)) {
        time ++
        db.inputEnabled = false
        dg.inputEnabled = false
        dy.inputEnabled = false
        dr.inputEnabled = false

        if(time == 25) {
            time = 0
            pBlue = false
            pRed = false
            pGreen = false
            pYellow = false

            lb.alpha = 0
            ly.alpha = 0
            lr.alpha = 0
            lg.alpha = 0

            db.inputEnabled = true
            dy.inputEnabled = true
            dr.inputEnabled = true
            dg.inputEnabled = true
        }
    }
    if(toRiel == true) {
        timer ++
        howTo()
    }
    if(toRiel == false) {
    testOnly()
    }
}
}
let dy, dg, dr, db, ly, lr, lb, back, time = 0, timer = 0
let pBlue = false, pRed = false, pYellow = false, pGreen = false
let toRiel = true
let one1 = false, two2 = false, three3 = false, four4 = false, five5 = false

function blue() {
    pBlue = true   

    lb.alpha = 1
}
function green() {
    pGreen = true 
    
    lg.alpha = 1
}
function red() {
    pRed = true  
    
    lr.alpha = 1
}
function yellow() {
    pYellow = true   
    
    ly.alpha = 1
}

function howTo() {
    db.inputEnabled = false
    dg.inputEnabled = false
    dy.inputEnabled = false
    dr.inputEnabled = false
    if(timer == 10) {
        ly.alpha = 1

    }        
    if(timer == 30) {
        ly.alpha = 0
        lr.alpha = 1
    }
    if(timer == 50) {
        lr.alpha = 0
        lg.alpha = 1
    }
    if(timer == 70) {
        lg.alpha = 0
        lb.alpha = 1
    }
    if(timer == 90) {
        lb.alpha = 0
        lg.alpha = 1
    }
    if(timer == 110) {
        lg.alpha = 0

        db.inputEnabled = true
        dy.inputEnabled = true
        dr.inputEnabled = true
        dg.inputEnabled = true

        toRiel = false
        timer = 0
    }
}

function testOnly() {    
    if(one1 == false) {
        if ((pGreen == true)||(pRed == true)||(pBlue == true)) {
        toRiel = true
    }
}

    if(pYellow == true) {
        one1 = true
    }

    if(one1 == true) {
        if(pRed == true) {
            two2 = true
        }
    }
    if((two2 == true)) {
        if(pGreen == true) {
            three3 = true
        }    
    }
    if(three3 == true) {
        if(pBlue == true) {
            four4 = true
        }
    }
    if(four4 == true) {
        if(pGreen == true) {
            five5 = true
        }
    }
    if(five5 == true) {
        doneDuck = true
        game.state.start('fourth',level4State)
    }
}