"use strict"
const level3State={

preload:function() 

{
    game.load.image("test", "images/KNP/test3.png") 
    game.load.image("wrong", "images/KNP/wrong.png") 
    game.load.image("correct", "images/KNP/correct.png") 
    game.load.image("throwoff", "images/KNP/throwoff.png") 
},

create:function()

{
    test = game.add.image(0, 0, "test")

    throwoff = game.add.image(180, 290, "throwoff")
    throwoff.inputEnabled = true
    throwoff.events.onInputDown.add(Wrong)

    correct = game.add.image(180, 430, "correct")
    correct.inputEnabled = true
    correct.events.onInputDown.add(Correct)

    wrong = game.add.image(0, 0, "wrong")
    wrong.alpha = 0
}, 

update:function()

{ 
}
}

let test
let correct, wrong
let throwoff

function Wrong() {
    wrong.alpha = 1
}
function Correct() {
    doneTest = true
    game.state.start('second',level2State)
}