"use strict"
const level7State={

preload:function() 

{
    game.load.image('clock', 'images/LGP/LGPTogether.png')
    game.load.image('redc', 'images/LGP/redc.png')
},

create:function()

{
    clock = game.add.image(0, 0, "clock")

    redc = game.add.image(360, 360, "redc")
    redc.anchor.setTo(0.5)

    game.physics.enable(redc)
    redc.inputEnabled = true
    
    cursors = game.input.keyboard.createCursorKeys()
    spaceKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR)
}, 

update:function()

{         
    smaller -= rate 
    redc.scale.setTo(smaller)

    if(smaller <= 0.02) {
        smaller = 1
        redc.scale.setTo(1)
    }
    if(spaceKey.isDown) {
        rate = 0
        if((smaller <= 0.48)&&(smaller >=  0.3)) {
            game.state.start('eighth',level8State)
            doneClock = true
        }
        else {
        rate = 0.01
        smaller = 1
        }
    }
}
}

let clock, redc
let smaller = 1
let cursors, spaceKey
let rate = 0.01
